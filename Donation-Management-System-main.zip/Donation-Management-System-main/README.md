# Charity-Jet--Donation-Website
Charity Jet is a Donation Website with integrated payment gateway using Razorpay. 
